<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
</head>
<body>
<form action="multiple_upload_ac.php" method="post" enctype="multipart/form-data">
  <p><input type="file" name="file_array[]" multiple=""></p>
  <input type="submit" name="insert" value="Upload all files">
</form>
</body>
</html>